<template>
  <v-footer color="accent-4" dark>
    <v-container>
      <v-row>
        <v-col color="white">
          Joel del Val Soler <br>
          joeldelvalsoler@gmail.com
        </v-col>
      </v-row>
    </v-container>
  </v-footer>
</template>


<script>
  export default {
    name: 'Footer'
  }
</script>
